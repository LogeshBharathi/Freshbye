
use project;



-- INSERT INTO user (email,username,password) VALUES ("freekyajmal@gmail.com","Muthu","Ajmal112");

SELECT * FROM user;

DELETE FROM user;